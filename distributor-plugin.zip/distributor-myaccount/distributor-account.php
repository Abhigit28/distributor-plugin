<?php 

function add_retailer_user_role() { 
    add_role('retailer', 'Retailer', array(
        'read' => true, // True allows that capability
        'edit_posts' => false,
        'delete_posts' => false, // Use false to explicitly deny
    ));
}
add_action( 'admin_init', 'add_retailer_user_role');

add_action( 'woocommerce_register_form', 'wporg_myplugin_add_registration_fields' );
function wporg_myplugin_add_registration_fields() {
 
    // Get and set any values already sent
    $enable_register_form = get_option( 'enable_register_form' );

    if ($enable_register_form == 'yes') {
        ?>
        <p class="form-row form-row-wide">
            <label for="user_role">
                <input type="checkbox" name="user_role" value="retailer" id="user_role" />
                <span>I am Retailer</span>
            </label>
        </p>
        <div class="clear"></div>
        <?php
    }
}

// Add the custom field "user_role"
add_action( 'woocommerce_edit_account_form', 'add_user_role_to_edit_account_form' );
function add_user_role_to_edit_account_form() {

    $user = wp_get_current_user();
    $retailer_key = get_user_meta($user->ID, 'retailer_key', true);
    $retailer_user_status = get_user_meta($user->ID, 'retailer_user_status', true);
    $new_registration = get_user_meta($user->ID, 'new_registration', true);
    $user_meta = get_userdata($user->ID);
    $user_roles = $user_meta->roles[0];
    if ($retailer_key && $user_roles == 'retailer') {
        ?>
        <fieldset>
            <legend>Site Details</legend>
            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="distributor_site_url"><?php esc_html_e( 'Distributor Site Url', 'distributor' ); ?></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="distributor_site_url" id="distributor_site_url" readonly value="<?php echo site_url('/'); ?>" />
            </p>
            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="retailer_site_url"><?php esc_html_e( 'Retailer Site Url', 'distributor' ); ?> <span class="required">*</span></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="retailer_site_url" id="retailer_site_url" value="<?php echo esc_attr( $user->retailer_site_url ); ?>" />
            </p>
            <?php  
            if ($retailer_user_status == 'approved') { ?>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide retailer_id">
                    <label for="user_id"><?php _e( 'Retailer Id', 'distributor' ); ?></label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="user_id" id="user_id" readonly value="<?php echo esc_attr( $user->ID ); ?>" />
                </p>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide retailer_key">
                    <label for="retailer_key"><?php _e( 'Your Retailer Key', 'distributor' ); ?></label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="retailer_key" id="retailer_key" readonly value="<?php echo esc_attr( $retailer_key ); ?>" />
                </p>
                <div class="retailerkey_tooltip">
                    <button type="button" onclick="copyretailerkey()" onmouseout="outFunc()" class="copy_retailer_key" id="copy_retailer_key" >
                        <span class="retailerkey_tooltiptext" id="retailerkeyTooltip">Copy to clipboard</span>
                        Copy key
                    </button>
                </div>
            <?php }
                if ( $retailer_user_status == 'unapproved' && $new_registration == 'false') {
                    $message = sprintf( __( '<p>Your account is unapproved. Please contact to support - [%s]</p>', 'distributor' ), get_option( 'blogname' ) );
                }elseif ($retailer_user_status == 'unapproved' && $new_registration == 'true') {
                    $message = sprintf( __( '<p>Your registration is pending for approval - [%s]</p>', 'distributor' ), get_option( 'blogname' ) );
                }
                
                echo $message;

            ?>
        </fieldset>
        <?php
    }
}

add_action( 'woocommerce_save_account_details', 'cssigniter_save_account_details' );
function cssigniter_save_account_details( $user_id ) {
    if ( isset( $_POST['retailer_site_url'] ) ) {
        update_user_meta( $user_id, 'retailer_site_url', sanitize_text_field( $_POST['retailer_site_url'] ) );
    }
}

// Make it required
add_filter( 'woocommerce_save_account_details_required_fields', 'misha_make_field_required' );
function misha_make_field_required( $required_fields ){
	$required_fields[ 'retailer_site_url' ] = 'Retailer Site Url';
	return $required_fields;
}

// To save WooCommerce registration form custom fields.
add_action( 'woocommerce_created_customer', 'wc_save_registration_form_fields' );
function wc_save_registration_form_fields( $customer_id ) {
    if ( isset($_POST['user_role']) ) {
        if( $_POST['user_role'] == 'retailer' ){
            $user = new WP_User($customer_id);
            $user_login = stripslashes( $user->data->user_login );
            $user_email = stripslashes( $user->data->user_email );
            $user->set_role('retailer');

            $userdata = get_userdata($customer_id);
            $retailer_key = md5($userdata->ID.$userdata->user_login.$userdata->user_registered);
            update_user_meta($customer_id, 'retailer_key', $retailer_key);
            update_user_meta( $customer_id, 'retailer_user_status', 'unapproved' );
            update_user_meta( $customer_id, 'new_registration', 'true' );

            //do_action('distributor_default_registeration_welcome_email', $user_login, $user_email);
        }
    }
}

add_action( 'user_profile_update_errors','wooc_validate_custom_field', 10, 1 );
add_action( 'woocommerce_save_account_details_errors','wooc_validate_custom_field', 10, 1 );
function wooc_validate_custom_field( $args ){

	$already_regi_site_url = get_users(
	    array(
	        'role' => 'retailer',
	        'exclude' => get_current_user_id(),
	        'meta_query' => array(
	            array(
	                'key' => 'retailer_site_url',
	                'value' => $_POST['retailer_site_url'],
	                'compare' => '=='
	            )
	        )
	    )
	);

	if ($already_regi_site_url) {
	    if ( isset( $_POST['retailer_site_url'] ) ) {
	        $args->add( 'error', __( ''.$_POST['retailer_site_url'].' is already used in this site.', 'distributor' ),'');
	    }
	}
}