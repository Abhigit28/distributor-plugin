<?php 

/**
 * @package Retailers\Classes
 * @version 1.0.0
 **/


/**
 * Retailers class.
**/

class Retailers{

	protected $namespace = 'api/retailer';

	public function __construct(){
		add_action('rest_api_init', array($this, 'JsonretailerApi'));
	}

	public function JsonretailerApi(){
		register_rest_route($this->namespace, '/verify_retailer', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'verify_retailer']
        ]);

        register_rest_route($this->namespace, '/retailer_info', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'retailer_info']
        ]);
	}

	public function verify_retailer($request) {
        $parameters = $request->get_json_params();
        extract($parameters);

        if(empty($retailer_key_id)){
			$response['status'] = false;
			$response['message'] = "Please insert Retailer Key";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($retailer_id)){
			$response['status'] = false;
			$response['message'] = "Please insert Retailer id";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		$retailer_key = get_user_meta($retailer_id, 'retailer_key', true);

		if ($retailer_key == $retailer_key_id) {
			$response['status'] = true;
			$response['insert_in'] = true;
			$response['message'] = "Retailer Key Verified";
			$response['data'] = array(
				'retailer_key' => $retailer_key_id,
				'retailer_id' => $retailer_id
			);

		}else{
			$response['status'] = true;
			$response['message'] = "Retailer Key not found";
			$response['data'] = $retailer_key_id;
		}
		
		return new WP_REST_Response($response, 200);

	}

	public function retailer_info($request) {
        $parameters = $request->get_json_params();
        extract($parameters);

        if(empty($retailer_key_id)){
			$response['status'] = false;
			$response['message'] = "Please insert Retailer Key";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($retailer_id)){
			$response['status'] = false;
			$response['message'] = "Please insert Retailer id";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		$retailer_key 	= get_user_meta($retailer_id, 'retailer_key', true);
		$user_meta 		= get_user_meta($retailer_id);

		$data = array_filter(
	                array_map(function ($a) {
	                    return $a[0];
	                }, $user_meta)
	            );

		if ($retailer_key == $retailer_key_id) {
			$response['status'] = true;
			$response['message'] = "Retailer info";
			$response['data'] = $data;

		}else{
			$response['status'] = true;
			$response['message'] = "Retailer Key not found";
			$response['data'] = $retailer_key_id;
		}
		
		return new WP_REST_Response($response, 200);

	}
}

$Retailers = new Retailers();