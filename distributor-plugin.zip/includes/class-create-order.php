<?php

/**
 * Create Order
 *
 * @package Distributor\Classes
 * @version 1.0.0
 */


/**
 * WooPayment class.
 */

class WooPayment {

	/**
	 * Route base.
	 *
	 * @var string
	 */
    protected $namespace = 'api/process';

	public function __construct() {

        add_action('rest_api_init', array($this, 'JsonPaymentApi'));

    }

	/**
	 * Register the routes for order.
	 */
	public function JsonPaymentApi() {

		register_rest_route($this->namespace, 'create_order', array(
			'methods' => WP_REST_Server::CREATABLE, 
			'callback' => array($this, 'create_order')
		));

	}

	/**
	 * create order from the REST request.
	 *
	 * @param array $request Request array.
	 * @return array
	 */
	public function create_order($request) {

		$parameters = $request->get_json_params();

		extract($parameters);

        if(empty($retailer_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		if(empty($retailer_key_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_key_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		$user = get_userdata($retailer_id);

		$retailer_meta = get_user_meta($retailer_id);

		if (defined('WC_ABSPATH')) {

			include_once WC_ABSPATH . 'includes/wc-cart-functions.php';

			include_once WC_ABSPATH . 'includes/wc-notice-functions.php';

			include_once WC_ABSPATH . 'includes/wc-template-hooks.php';

		}

		global $woocommerce;


		$Retailers = new Retailers();
        $retailer_info = $Retailers->retailer_info($request);

        if ($retailer_info->data['status'] == true) {

        	$retailer_data = $retailer_info->data['data'];

	        $Billing_address = array(
	           'first_name' => $retailer_data['billing_first_name'],
	           'last_name'  => $retailer_data['billing_last_name'],
	           'email'      => $retailer_data['billing_email'],
	           'phone'      => $retailer_data['billing_phone'],
	           'address_1'  => $retailer_data['billing_address_1'],
	           'address_2'  => $retailer_data['billing_address_2'],
	           'city'       => $retailer_data['billing_city'],
	           'state'      => $retailer_data['billing_state'],
	           'postcode'   => $retailer_data['billing_postcode'],
	           'country'    => $retailer_data['billing_country']
	        );

	        $billing_blank = 0;
	        foreach($Billing_address as $keys){
	            if(!empty($keys)) {
	                $billing_blank++;
	            }
	        }

	        if($billing_blank > 0){
	            $billing_empty = 'false';
	        }else {
	            $billing_empty = 'true';
	        }

	        if ($billing_empty == 'false') {
	            $addressBilling = $Billing_address;
	        }else{
	            $addressBilling = $addressBilling;
	        }
        }

		$retailer_site_url 			= $retailer_meta['retailer_site_url'][0];
		$retailer_discount_title 	= $retailer_meta['discount_title'][0];
		$_retailer_discount 		= $retailer_meta['retailer_discount'][0];

		$global_discount 			= get_option('global_discount');
		$global_discount_title 		= get_option('global_discount_title');

		if (!empty($retailer_discount_title)) {
			$discount_title = $retailer_discount_title;
		}elseif (empty($retailer_discount_title) && !empty($global_discount_title)) {
			$discount_title = $global_discount_title;
		}else{
			$discount_title = 'Discount';
		}

		if (!empty($_retailer_discount)) {
			$retailer_discount = $_retailer_discount;
		}elseif (empty($_retailer_discount) && !empty($global_discount)) {
			$retailer_discount = $global_discount;
		}else{
			$retailer_discount = '0';
		}

		if($products){

			// Now we create the order
  			$order = wc_create_order();

  			foreach ($products as $key => $product) { 
				$order->add_product( wc_get_product( $product['distributor_pro_id'] ), $product['item_quantity'] ); //Add product to order
  			}

			$order->update_meta_data( '_retailer_order_info', serialize($retailer_order_info) );
			$order->update_meta_data( '_retailer_product_info', serialize($products) );
			$order->set_address($addressBilling, 'billing'); //Add billing address

			$order->set_address($addressShipping, 'shipping'); //Add shipping address

			$order->set_customer_id($retailer_id);
			$order->set_created_via( 'retailer_site' );

			//Set payment gateways
			$payment_gateways = WC()->payment_gateways->payment_gateways();
			$order->set_payment_method($payment_gateways['stripe']);

			$order->calculate_totals(true); //setting true included tax 

			$subtotal = $order->get_subtotal();

			if ($_retailer_discount || $global_discount) {
				$this->order_add_discount( $order->get_id(), __("".$discount_title." (".$retailer_discount."%)"), ''.$retailer_discount.'%' );
			}else{
				$order->set_total( $subtotal );
			}

			$order_id = $retailer_order_info['order_id'];

			// The text for the note
			$note = __("Retailer Order id #".$order_id.""); 
			// Add the note
			$order->add_order_note( $note );


			$create_payment = $this->create_payment($order->get_id());

			$response['status'] = "Success";

			$response['order'] = $order->get_id();

			$response['data'] = $products;

			$response['paymentIntent'] = $create_payment['paymentIntent'];

			$response['message'] = "Order Sucessfully Placed.";

			$response['stripe_message'] = $create_payment['stripe_message'];

			return new WP_REST_Response($response, 200);

		}else{

			$response['status'] = "error";

			$response['message'] =  "Cart Empty.";

			return new WP_REST_Response($response, 200);

		}
	}

	/**
	 * Add a discount to an retailer Orders
	 * (Using the API)
	 *
	 * @param  int     $order_id  The order ID. Required.
	 * @param  string  $title  The label name for the discount. Required.
	 * @param  mixed   $amount  Fixed amount (float) or percentage based on the subtotal. Required.
	 * @param  string  $tax_class  The tax Class. '' by default. Optional.
	 */
	function order_add_discount( $order_id, $title, $amount, $tax_class = '' ) {
	    $order    = wc_get_order($order_id);
	    $subtotal = $order->get_subtotal();
	    $item     = new WC_Order_Item_Fee();

	    if ( strpos($amount, '%') !== false ) {
	        $percentage = (float) str_replace( array('%', ' '), array('', ''), $amount );
	        $percentage = $percentage > 100 ? -100 : -$percentage;
	        $discount   = $percentage * $subtotal / 100;
	    } else {
	        $discount = (float) str_replace( ' ', '', $amount );
	        $discount = $discount > $subtotal ? -$subtotal : -$discount;
	    }

	    $item->set_tax_class( $tax_class );
	    $item->set_name( $title );
	    $item->set_amount( $discount );
	    $item->set_total( $discount );

	    if ( '0' !== $item->get_tax_class() && 'taxable' === $item->get_tax_status() && wc_tax_enabled() ) {
	        $tax_for   = array(
	            'country'   => $order->get_shipping_country(),
	            'state'     => $order->get_shipping_state(),
	            'postcode'  => $order->get_shipping_postcode(),
	            'city'      => $order->get_shipping_city(),
	            'tax_class' => $item->get_tax_class(),
	        );
	        $tax_rates = WC_Tax::find_rates( $tax_for );
	        $taxes     = WC_Tax::calc_tax( $item->get_total(), $tax_rates, false );

	        if ( method_exists( $item, 'get_subtotal' ) ) {
	            $subtotal_taxes = WC_Tax::calc_tax( $item->get_subtotal(), $tax_rates, false );
	            $item->set_taxes( array( 'total' => $taxes, 'subtotal' => $subtotal_taxes ) );
	            $item->set_total_tax( array_sum($taxes) );
	        } else {
	            $item->set_taxes( array( 'total' => $taxes ) );
	            $item->set_total_tax( array_sum($taxes) );
	        }
	        $has_taxes = true;
	    } else {
	        $item->set_taxes( false );
	        $has_taxes = false;
	    }
	    $item->save();

	    $order->add_item( $item );
	    $order->calculate_totals( $has_taxes );
	    $order->save();
	}

	function create_payment($order_id){
		
		$order = wc_get_order( $order_id );
		$customer_name = $order->get_billing_first_name().' '.$order->get_billing_last_name();
		$email = $order->get_billing_email();
		$amount = $order->get_total();
		$currency = strtolower( get_woocommerce_currency() );

		@include_once "includes/stripe/stripe-php/init.php";
		try {

			// Get stripe  test or secret key from woocommerce settings
			$options = get_option( 'woocommerce_stripe_settings' );
			$stripeKey = 'yes' === $options['testmode'] ? $options['test_secret_key'] : $options['secret_key'] ;

			//Set the Stripe API Key
			\Stripe\Stripe::setApiKey($stripeKey);

			//Get Stripe customer token that was created when the card was saved in woo
			$user_id = get_post_meta($order_id, '_customer_user', true);
			$tokenString = get_user_meta($user_id, 'wp__stripe_customer_id', true);
			//Get total for the order as a number

			//Charge user via Stripe API
			$charge = \Stripe\Charge::create([
				'customer' => $tokenString,
				'amount' => $amount*100 ,
				'currency' => $currency,
				'description' => site_url().' - '.$order_id,
				'metadata' => array(
					'order_id' => $order_id
				)
			]);
	
			$response['paymentIntent'] = $charge->jsonSerialize();

            $order->add_order_note( sprintf( __( 'Payment transferred to admin account.', 'distributor' ) ) );

			//Set all the meta data that will be needed
			$order->update_meta_data( '_transaction_id', $charge->id );
			$order->update_meta_data( '_stripe_source_id', $charge->payment_method );
			$order->update_meta_data( '_stripe_charge_captured', 'yes'  );
			$order->update_meta_data( '_stripe_currency', $charge->currancy);
			$order->update_meta_data( 'wp__stripe_customer_id', $charge->customer);

			if ($charge->id) {
				$order->add_order_note( __( 'Stripe charge complete (Charge ID: '.$charge->id.')', 'distributor' ) );
				$order->update_status('processing');
			}else{
				$order->add_order_note( __( 'Please check your card details.', 'distributor' ) );
				$order->update_status('on-hold');
			}

		} catch (\Stripe\Error\Base $e) {
		  // Code to do something with the $e exception object when an error occurs
		  echo($e->getMessage());
		} catch (Exception $e) {
		  echo($e->getMessage());
		  // Catch any other non-Stripe exceptions
		}

		$response['stripe_message'] = "Stripe payment is completed successfully. The TXN ID is " . $charge->balance_transaction;

		return $response;
	}
}

$WooPayment = new WooPayment();