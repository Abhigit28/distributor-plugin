<?php 

class WOOProducts{

	protected $namespace = 'api/products';

	public function __construct(){
		add_action('rest_api_init', array($this, 'JsonProductApi'));
	}

	public function JsonProductApi(){
        register_rest_route($this->namespace, '/products_categories', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'products_categories']
        ]);
        register_rest_route($this->namespace, '/category_products', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'category_products']
        ]);
	}

	public function products_categories($request) {
        $parameters = $request->get_json_params();
        $data = array();
        extract($parameters);
		if ($per_page) { 

		}else{ 
			$parameters['per_page'] = 10; 
		}
        if ($page) { 

        }else{ 
        	$parameters['page'] = 1; 
        }
		if($per_page == 'all'){
			$parameters['per_page'] = 100;
		}

        if(empty($retailer_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

        if(empty($retailer_key_id)){
			$response['status'] = false;
			$response['message'] = "You must include a 'retailer_key_id' var in your request.";
			$response['data'] = null;
			return new WP_REST_Response($response, 200);
		}

		$args = array(
			'taxonomy'     => 'product_cat',
			'orderby'      => 'name',
			'show_count'   => 1, // 1 for yes, 0 for no
			'pad_counts'   => 1, // 1 for yes, 0 for no
			'hierarchical' => 1, // 1 for yes, 0 for no
			'title_li'     => '',
			'hide_empty'   => 1
		);
		$all_categories = get_categories( $args );

        $cat_min_data = array();
        foreach($all_categories as$category => $cat){

		    // get the thumbnail id using the queried category term_id
		    $thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true ); 

		    // get the image URL
		    $image = wp_get_attachment_url( $thumbnail_id ); 

            $cat_data = array();
            $cat_data['term_id'] =  $cat->term_id;
            $cat_data['name'] =  !empty($cat->name) ? $cat->name : '';
            $cat_data['slug'] =  !empty($cat->slug) ? $cat->slug : '';
            $cat_data['image_url'] = !empty($image) ? $image : '';
            $cat_data['product_count'] = !empty($cat->count) ? $cat->count : '';
            $cat_min_data[] = $cat_data;
        }

        $data['count'] = count($cat_min_data);
		$data['parameters'] = $parameters;
        $data['categories'] = $cat_min_data;

        $response['status'] = true;
        $response['retailer_verify'] = "Retailer Verified";
        $response['message'] = "Product categories list";
        $response['data'] = $data;
        return new WP_REST_Response($response, 200);

	}

	public function category_products($request) {
        $parameters = $request->get_json_params();
        $data = array();
        extract($parameters);

		if (!$category) {
			$response['status'] = false;
			$response['message'] = "category Id Not found.";
			return new WP_REST_Response($response, 200);
		}

        if(empty($retailer_id)){
            $response['status'] = false;
            $response['message'] = "You must include a 'retailer_id' var in your request.";
            $response['data'] = null;
            return new WP_REST_Response($response, 200);
        }

        if(empty($retailer_key_id)){
            $response['status'] = false;
            $response['message'] = "You must include a 'retailer_key_id' var in your request.";
            $response['data'] = null;
            return new WP_REST_Response($response, 200);
        }

        $cat_products = get_posts( array(
            'post_type' => 'product',
            'numberposts' => -1,
            'post_status' => 'publish',
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'id',
                    'terms' => $category,
                )
            ),
        ) );

        $cat_all_products = array();
        foreach ($cat_products as $key => $product ) {
            $_product = wc_get_product($product->ID);

            $prod_id = $product->ID;

            $categories = array();
            $product_cats = get_the_terms(  $_product->get_id(), 'product_cat' );
            if ($product_cats) {
                foreach($product_cats as $key => $cat) {
                    $cat_data = array();
                    $cat_data['term_id'] = $cat->term_id;
                    $cat_data['name'] = $cat->name;
                    $cat_data['slug'] = $cat->slug;
                    $cat_data['image_url'] = '';
                    $categories[] = $cat_data;
                }
            }

            $tags = array();
            $product_tag = get_the_terms(  $_product->get_id(), 'product_tag' );
            if ($product_tag) {
                foreach($product_tag as $key => $tag) {
                    $tag_data = array();
                    $tag_data['term_id'] = $tag->term_id;
                    $tag_data['name'] = $tag->name;
                    $tag_data['slug'] = $tag->slug;
                    $tag_data['image_url'] = '';
                    $tags[] = $tag_data;
                }
            }

            $term_id = !empty($categories[0]['term_id']) ? $categories[0]['term_id'] : 0;
            $cat_name = !empty($categories[0]['name']) ? $categories[0]['name'] : '';
            $cat_slug = !empty($categories[0]['slug']) ? $categories[0]['slug'] : '';

            $p_data = array();
            $image_url = wp_get_attachment_url( get_post_thumbnail_id( $_product->get_id()), 'single-post-thumbnail' );
            // $gallery_image_ids = $_product->get_gallery_image_ids();

            $p_data['id'] = (int)$_product->get_id();
            $p_data['name'] = (string)$_product->get_name();
            $p_data['slug'] = (string)$_product->get_slug();
            $p_data['permalink'] = (string)get_permalink( $_product->get_id() );
            $p_data['date_created'] = (string)date('d/m/Y',strtotime($_product->get_date_created()));
            $p_data['type'] = (string)$_product->get_type();
            $p_data['description'] = (string)$_product->get_description();
            $p_data['short_description'] = (string)$_product->get_short_description();
            $p_data['price'] = (string)$_product->get_price();
            $p_data['regular_price'] = (string)$_product->get_regular_price();
            $p_data['sale_price'] = (string)$_product->get_sale_price();
            $p_data['currency_symbol'] = html_entity_decode(get_woocommerce_currency_symbol());
            $p_data['average_rating'] = '0.00';
            $p_data['rating_count'] = 0;
            $p_data['manage_stock'] = $_product->get_manage_stock();
            $p_data['stock_status'] = (string)$_product->get_stock_status();
            $p_data['stock_quantity'] = (string)$_product->get_stock_quantity();
            $p_data['backorders'] = $_product->get_backorders();
            $p_data['sold_individually'] = $_product->get_sold_individually();
            $p_data['low_stock_amount'] = (string)$_product->get_low_stock_amount();
            $p_data['on_sale'] = $_product->is_on_sale();
            $p_data['purchasable'] =  $_product->is_purchasable();
            $p_data['featured'] = $_product->is_featured();
            $p_data['virtual'] = $_product->is_virtual();
            $p_data['downloadable'] = $_product->is_downloadable();
            $p_data['categories'] = $categories;
            $p_data['tags'] = $tags;
            $p_data['image_url'] = !empty($image_url) ? $image_url : '';
            // $p_data['gallery_images'] = !empty($gallery_image_ids) ? $gallery_image_ids : [];

            $attr_arr = array();
            if($_product->get_type() == 'variable') {
                $attributes = $_product->get_attributes();
                foreach( $attributes as $key => $value ) {
                    $attr_data = array();
                    $attr_data['name'] = $attribute_name = ucfirst(preg_replace( '/pa_/', '', $key ));
                    $attr_data['key_name'] = 'attribute_'.$key;
                    $attr_data_items = wc_get_product_terms( $_product->get_id(), $key );
                    $i = 0;
                    foreach ($attr_data_items as $ati_key => $ati_data) {
                        if($i == 0){
                            $ati_data->is_selected = true;
                        }else{
                            $ati_data->is_selected = false;
                        }
                        $attr_data['items'][$ati_key] = $ati_data;
                        $i++;
                    }
                    $attr_arr[] = $attr_data;
                }
            }
            $p_data['attribute_data'] = $attr_arr?$attr_arr:[];

            $productswish[] = $p_data;	
        }
        
        $data['products'] = $productswish;

        $response['status'] = true;
        $response['count'] = count($cat_products);
        $response['message'] = "category products";
        $response['category_products'] = $data;
        return new WP_REST_Response($response, 200);
	}
}

$WOOProducts = new WOOProducts();