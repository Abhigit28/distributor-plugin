<?php
//namespace PhpPot\Service;
//namespace PhpPot\Service\Token;
////use PhpPot\Service\StripePayment;
//
//require_once 'vendor/autoload.php';
//
//use \Stripe\Stripe;
//use \Stripe\Customer;
//use \Stripe\ApiOperations\Create;
//use \Stripe\Charge;
//use WP_REST_Response;
//use \Stripe\PaymentIntent;
//use Exception;
//use Stripe\Source;
//use WC_Payment_Tokens;
//use WC_Payment_Gateway_CC;
//use WeDevs\DokanPro\Modules\Stripe\Helper;

namespace PhpPot\Service;

@include_once "includes/stripe/stripe-php/init.php";

use \Stripe\Stripe;
use \Stripe\Customer;
use \Stripe\ApiOperations\Create;
use \Stripe\Charge;



//use WeDevs\DokanPro\Modules\Stripe\Customer;
//use WeDevs\Dokan\Withdraw\Manager\Withdraw;
//use WeDevs\Dokan\Exceptions\DokanException;

class StripePayment
{

    private $apiKey;

    private $stripeService;

    public function __construct()
    {
        require_once "config.php";
        $this->apiKey = STRIPE_SECRET_KEY;
        $this->stripeService = new \Stripe\Stripe();
        $this->stripeService->setVerifySslCerts(false);
        $this->stripeService->setApiKey($this->apiKey);
    }

    public function addCustomer($customerDetailsAry)
    {
        
        $customer = new Customer();
        
        $customerDetails = $customer->create($customerDetailsAry);
        
        return $customerDetails;
    }

    public function chargeAmountFromCard($cardDetails)
    {	
		global $woocommerce;
		$order_id = $cardDetails->order_id;
		$order = wc_get_order( $order_id );
		$email = $order->get_billing_email();
		$amount = $order->get_total();
		$currency = strtolower( get_woocommerce_currency() );
		$stripe_customer_id = null;
        $force_save_source  = false;
        $customerDetailsAry = array(
            'email' => $email,
            'source' => $cardDetails->id
        );
		
		
        $customerResult = $this->addCustomer($customerDetailsAry);
       // $charge = new Charge();
		//$PaymentIntent = new PaymentIntent();
       /* $cardDetailsAry = array(
            'customer' => $customerResult->id,
            'amount' => $amount*100 ,
            'currency' => $currency,
            'description' => site_url().' - '.$order_id,
            'metadata' => array(
                'order_id' => $order_id
            ),
			//'source'=>$access_token 
        );*/
		
		// Create a PaymentIntent:
		
		$has_suborder = $order->get_meta( 'has_sub_order' );
        $all_orders   = [];

        if ( $has_suborder ) {
            $sub_order_ids = get_children( [ 'post_parent' => $order->get_id(), 'post_type' => 'shop_order', 'fields' => 'ids' ] );

            foreach ( $sub_order_ids as $sub_order_id ) {
                $sub_order    = wc_get_order( $sub_order_id );
                $all_orders[] = $sub_order;
            }
        } else {
            $all_orders[] = $order;
        }
		$response['orderdt'] = $all_orders;
		foreach ( $all_orders as $tmp_order ) {
            $tmp_order_id = $tmp_order->get_id();
            $seller_id    = dokan_get_seller_id_by_order( $tmp_order_id );
            $dokan_order  =self::get_dokan_order( $tmp_order_id, $seller_id );
			$access_token = get_user_meta( $seller_id, '_stripe_connect_access_key', true );
			$stripe_user_id = get_user_meta( $seller_id, 'stripe_user_id', true );
		
            if ( ! $dokan_order ) {
                throw new Exception( __( 'Something went wrong and the order can not be processed!', 'dokan' ) );
            }
			
			global $woocommerce;
 			$order = wc_get_order( $tmp_order_id );
		
            $order_total     = (float) $order->get_subtotal();
            $application_fee = $order_total - (float) $dokan_order->net_amount;
            $vendor_earning  = $order_total - $application_fee;

            if ( $dokan_order->order_total == 0 ) {
                $tmp_order->add_order_note( sprintf( __( 'Order %s payment completed', 'dokan' ), $tmp_order->get_order_number() ) );
                continue;
            }

            $access_token = get_user_meta( $seller_id, '_stripe_connect_access_key', true );
			$response['access_token'] = $access_token;
			$response['$seller_id'] = $seller_id;
			$response['orderdt'] = $dokan_order;
          

            if ( $token ) {
                
				$paymentIntent = \Stripe\PaymentIntent::create([
					//'customer' => $customerResult->id,
					'amount' => $amount*100 ,
					'currency' => $currency,
					'description' => site_url().' - '.$order_id,
					'metadata' => array(
						'order_id' => $order_id
					),
					'transfer_group' => '{ORDER'.$order_id.'}',
				]);
				
				$transfer = \Stripe\Transfer::create([
					//'customer' => $customerResult->id,
					'amount' => $vendor_earning*100 ,
					'currency' => $currency,
					'description' => site_url().' - '.$order_id,
					'destination' => $stripe_user_id,
					'metadata' => array(
						'order_id' => $order_id
					),
					'transfer_group' => '{ORDER'.$order_id.'}',
				]);
		
				
				
				$response['paymentIntent'] = $paymentIntent;
				$response['transfer'] = $transfer;
				
            } else {
                $order_desc = sprintf( __( '%s - Order %s, suborder of %s', 'dokan' ), esc_html( get_bloginfo( 'name' ) ), $tmp_order_id, $order->get_order_number() );
               
			   
			  //  $customerResult = $this->addCustomer($customerDetailsAry);
				$charge = new Charge();
				$cardDetailsAry = array(
					'customer' => $customerResult->id,
					'amount' => $amount*100 ,
					'currency' => $currency,
					'description' => site_url().' - '.$order_id,
					'metadata' => array(
						'order_id' => $order_id
					)
				);
				$result = $charge->create($cardDetailsAry);
		
				$response['paymentIntent'] = $result->jsonSerialize();

                $order->add_order_note( sprintf( __( 'Vendor payment transferred to admin account since the vendor had not connected to Stripe.', 'dokan' ) ) );
            }

            
        }
		
		
		return $response;
       
       // return $result->jsonSerialize();
    }
	
	 public function get_stripe_amount( $total ) {
        switch ( get_woocommerce_currency() ) {
            /* Zero decimal currencies*/
            case 'BIF' :
            case 'CLP' :
            case 'DJF' :
            case 'GNF' :
            case 'JPY' :
            case 'KMF' :
            case 'KRW' :
            case 'MGA' :
            case 'PYG' :
            case 'RWF' :
            case 'VND' :
            case 'VUV' :
            case 'XAF' :
            case 'XOF' :
            case 'XPF' :
            $total = absint( $total );
            break;
            default :
            $total = round( $total, 2 ) * 100; /* In cents*/
            break;
        }

        return $total;
    }
	
	public function get_dokan_order( $order_id, $seller_id ) {
        global $wpdb;

        $sql = "SELECT *
        FROM {$wpdb->prefix}dokan_orders AS do
        WHERE
        do.seller_id = %d AND
        do.order_id = %d";

        return $wpdb->get_row( $wpdb->prepare( $sql, $seller_id, $order_id ) );
    }
	
	public function get_intent_from_order( $order ) {
        $intent_id = $order->get_meta( 'dokan_stripe_intent_id' );

        if ( ! $intent_id ) {
            return false;
        }

        try {
            $intent = PaymentIntent::retrieve( $intent_id );
        } catch( Exception $e ) {
            return false;
        }

        return $intent;
    }
}
