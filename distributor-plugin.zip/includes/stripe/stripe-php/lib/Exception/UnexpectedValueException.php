<?php

namespace Stripe\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
