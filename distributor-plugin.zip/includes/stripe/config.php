<?php 

// Get stripe  test or secret key from woocommerce settings
$stripe_option = get_option( 'woocommerce_stripe_settings' );
// $stripeKey = 'yes' === $stripe_option['testmode'] ? $stripe_option['test_secret_key'] : $stripe_option['secret_key'] ;

if($stripe_option['testmode'] == 'yes'){
	$secret_key = $stripe_option['test_secret_key'];
	$publishable_key = $stripe_option['test_publishable_key'];
}else{
	$secret_key = $stripe_option['secret_key'];
	$publishable_key = $stripe_option['publishable_key'];
}
define("STRIPE_SECRET_KEY", $secret_key);
define("STRIPE_PUBLISHABLE_KEY", $publishable_key);
?>