<?php

use \PhpPot\Service\StripePayment;


class WPJsonWooPaymentStripe {
    protected $namespace = 'api/stripepayment';

    public function __construct()
    {
        require_once "config.php";
        $this->apiKey = STRIPE_SECRET_KEY;
        $this->stripeService = new \Stripe\Stripe();
        $this->stripeService->setVerifySslCerts(false);
        $this->stripeService->setApiKey($this->apiKey);

        add_action('rest_api_init', array($this, 'JsonWooPaymentApiStripe'));
    }

	public function JsonWooPaymentApiStripe() {
		register_rest_route($this->namespace, 'stripe_pay', array(
			'methods' => WP_REST_Server::CREATABLE, 
			'callback' => array($this, 'stripe_pay'), 
		));
	}

	public function stripe_pay($request) {
		$parameters = $request->get_json_params();
		extract($parameters);
		if (!class_exists('WooCommerce')) {
			$response['status'] = "error";
			$response['message'] = "Failed to process payment. WooCommerce either missing or deactivated.";
			return new WP_REST_Response($response, 200);
		}
		
		if (wc_get_order($order_id) == false) {
			$response['status'] = "error";
			$response['message'] = "Order ID 'order_id' is invalid. Order does not exist.";
			return new WP_REST_Response($response, 200);
		}
		// if (wc_get_order($order_id)->get_status() !== 'pending' && wc_get_order($order_id)->get_status() !== 'failed') {
		// 	$response['status'] = "error";
		// 	$response['message'] = "Order status is Neither 'pending' nor 'failed', meaning order had already received a successful payment. Multiple payment to the same order is not allowed.";
		// 	return new WP_REST_Response($response, 200);
		// }
		
		if (!$card_number) {
			$response['status'] = "error";
			$response['message'] = "Card Number 'card_number' is required.";
			return new WP_REST_Response($response, 200);
		}
		if (!$exp_month) {
			$response['status'] = "error";
			$response['message'] = "Card  expiry month 'exp_month' is required.";
			return new WP_REST_Response($response, 200);
		}
		
		if (!$exp_year) {
			$response['status'] = "error";
			$response['message'] = "Card expiry Date 'exp_year' is required.";
			return new WP_REST_Response($response, 200);
		}
		
		if (!$cvc) {
			$response['status'] = "error";
			$response['message'] = "Card CVC 'cvc' is required.";
			return new WP_REST_Response($response, 200);
		}
				
		// $dates = explode ("/", $exp_date); 
		// $exp_month = $dates[0];
		// $exp_year = $dates[1];

		//use \PhpPot\Service\StripePayment;

		require_once "config.php";
		
		try {	
			
			@include_once "includes/stripe/stripe-php/init.php";

			$stripe = new \Stripe\StripeClient(
			  STRIPE_SECRET_KEY
			);
			$tokandata = $stripe->tokens->create([
			  'card' => [
				'number' => $card_number,
				'exp_month' => $exp_month,
				'exp_year' => $exp_year,
				'cvc' => $cvc,
			  ],
			]);
			$tokandata->order_id = $order_id;
			$response['stripe_token'] = $tokandata->id;
			
			$stripeResponse = $this->chargeAmountFromCard($tokandata);

			$amount = $stripeResponse['paymentIntent']["amount"] /100;
			
			if ($stripeResponse['paymentIntent']['amount_refunded'] == 0 && empty($stripeResponse['paymentIntent']['failure_code']) && $stripeResponse['paymentIntent']['paid'] == 1 && $stripeResponse['paymentIntent']['captured'] == 1 && $stripeResponse['paymentIntent']['status'] == 'succeeded') {
				
				$customer_id = get_post_meta($order_id, '_customer_user', true);
				
				update_post_meta($order_id, '_stripe_charge_id_'.$customer_id, $stripeResponse['paymentIntent']["id"]);
				update_post_meta($order_id, '_date_paid', $stripeResponse['paymentIntent']["created"]);
				update_post_meta($order_id, '_payment_method', 'stripe-connect');
				update_post_meta($order_id, '_payment_method_title', 'Credit Card (Stripe Connect)');
				update_post_meta($order_id, 'stripe_transaction_id', $stripeResponse['paymentIntent']["balance_transaction"]);
				
				global $woocommerce;
				$order = wc_get_order( $order_id );
				$order->update_status('processing');
				$note = __("Order ".$order_id." payment is completed via Credit Card (Stripe Connect) on (Charge ID: ".$stripeResponse['paymentIntent']["id"].")");
				$order->add_order_note( $note );
				$order->save();
				
				
				//$response['code'] = 200;
				//$response['message'] = __("Payment Successful.", "wc-rest-payment");
				$response['stripe_message'] = "Stripe payment is completed successfully. The TXN ID is " . $stripeResponse['paymentIntent']["balance_transaction"];
				$response['stripe_data'] = $stripeResponse;
				
				$order->calculate_totals();
				$response['order'] = $order->get_id();
				$response['message'] = "Order Sucessfully Placed.";
				
				
			}
		} catch (Exception $e) {
			
				echo json_encode(array('status'=>400, 'message'=>$e->getMessage()));
				exit;
		}
		// Return Successful Response
		return new WP_REST_Response($response, 200);
	}

    public function chargeAmountFromCard($cardDetails){	
		global $woocommerce;
		$order_id = $cardDetails->order_id;
		$order = wc_get_order( $order_id );
		$customer_name = $order->get_billing_first_name().' '.$order->get_billing_last_name();
		$email = $order->get_billing_email();
		$amount = $order->get_total();
		$currency = strtolower( get_woocommerce_currency() );
		$stripe_customer_id = null;
        $force_save_source  = false;
        $customerDetailsAry = array(
            'name' => $customer_name,
            'email' => $email,
            'source' => $cardDetails->id
        );
		
        // Get the user ID
        $user_id = get_post_meta($order_id, '_customer_user', true);
		$stripe_user_id = get_user_meta( $user_id, 'stripe_user_id', true );
		
		global $woocommerce;
	
        $order_total     = (float) $order->get_subtotal();

		$response['access_token'] = $cardDetails->id;
		$response['user_id'] = $user_id;
		$response['orderdt'] = $order;

        if ( $stripe_user_id ) {
            
			$charge = new \Stripe\Charge();
			$cardDetailsAry = array(
				'customer' => $stripe_user_id,
				'amount' => $amount*100 ,
				'currency' => $currency,
				'description' => site_url().' - '.$order_id,
				'metadata' => array(
					'order_id' => $order_id
				)
			);
			$result = $charge->create($cardDetailsAry);
	
			$response['paymentIntent'] = $result->jsonSerialize();

            $order->add_order_note( sprintf( __( 'Payment transferred to admin account.', 'distributor' ) ) );
			
        } else {               
		   
		   $customerResult = $this->addCustomer($customerDetailsAry);

		   	update_user_meta( $user_id, 'stripe_user_id', true );

			$charge = new \Stripe\Charge();
			$cardDetailsAry = array(
				'customer' => $customerResult->id,
				'amount' => $amount*100 ,
				'currency' => $currency,
				'description' => site_url().' - '.$order_id,
				'metadata' => array(
					'order_id' => $order_id
				)
			);
			$result = $charge->create($cardDetailsAry);
	
			$response['paymentIntent'] = $result->jsonSerialize();

            $order->add_order_note( sprintf( __( 'Payment transferred to admin account.', 'distributor' ) ) );
        }

		return $response; 
    }

    public function addCustomer($customerDetailsAry){
        
		$stripe = new \Stripe\StripeClient(STRIPE_SECRET_KEY);

		$customerDetails = $stripe->customers->create($customerDetailsAry);

        return $customerDetails;
    }
}
$WPJsonWooPaymentStripe = new WPJsonWooPaymentStripe();
