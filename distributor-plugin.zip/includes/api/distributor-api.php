<?php 

/* Distributors Api's */

function verify_distributors_sitekey($retailer_key_id, $retailer_id, $retailer_site_url) {

  $distributor_site_url = site_url('/');

  $curl = curl_init();

  $parameters = array("retailer_key_id" =>$retailer_key_id,"retailer_id"=>$retailer_id,"distributor_site_url"=>$distributor_site_url);

  curl_setopt_array($curl, array(
    CURLOPT_URL => $retailer_site_url.'wp-json/api/distributor/verify_distributor',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($parameters),
    CURLOPT_HTTPHEADER => array(
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);

  return $response;

}

function retailer_order_update($retailer_id, $retailer_key_id, $retailer_site_url, $retailer_order_id, $products, $new_status) {

  $distributor_site_url = site_url('/');

  $curl = curl_init();

  $parameters = array("retailer_key_id" =>$retailer_key_id,"retailer_id"=>$retailer_id,"order_id"=>$retailer_order_id,"products"=>$products,"order_status"=> $new_status);

  curl_setopt_array($curl, array(
    CURLOPT_URL => $retailer_site_url.'wp-json/api/orders/update_order',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($parameters),
    CURLOPT_HTTPHEADER => array(
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);

  return $response;

}

function retailer_update_product($retailer_id, $retailer_key_id, $retailer_site_url, $distributor_product_id, $product_data) {

  $curl = curl_init();

  $parameters = array(
    "retailer_key_id" => $retailer_key_id, 
    "retailer_id" => $retailer_id,
    "distributor_product_id"=> $distributor_product_id,
    "product_data"=> $product_data
  );

  curl_setopt_array($curl, array(
    CURLOPT_URL => $retailer_site_url.'wp-json/api/product/update_product',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($parameters),
    CURLOPT_HTTPHEADER => array(
      'Content-Type: application/json'
    ),
  ));

  $response = curl_exec($curl);

  curl_close($curl);

  return json_encode($parameters);

}