<?php 

// Define a constant to use with html emails
define("HTML_EMAIL_HEADERS", array('Content-Type: text/html; charset=UTF-8'));

// @email - Email address of the reciever
// @subject - Subject of the email
// @heading - Heading to place inside of the woocommerce template
// @message - Body content (can be HTML)
function send_email_woocommerce_style($email, $subject, $heading, $message) {

  // Get woocommerce mailer from instance
  $mailer = WC()->mailer();

  // Wrap message using woocommerce html email template
  $wrapped_message = $mailer->wrap_message($heading, $message);

  // Create new WC_Email instance
  $wc_email = new WC_Email;

  // Style the wrapped message with woocommerce inline styles
  $html_message = $wc_email->style_inline($wrapped_message);

  // Send the email using wordpress mail function
  $mailer->send( $email, $subject, $html_message, HTML_EMAIL_HEADERS );

}

/**
 * The single_retailer_discount that will be save to single retailer discount.
 *
 */
function single_retailer_discount(){
	
	$retailer_id 		= $_POST['retailer_id'];
	$discount_title 	= $_POST['discount_title'];
	$retailer_discount 	= $_POST['retailer_discount'];

	if ($retailer_id && $retailer_discount) {
		delete_user_meta($retailer_id, 'dis_title', true);
		update_user_meta($retailer_id, 'discount_title', $discount_title);
		update_user_meta($retailer_id, 'retailer_discount', $retailer_discount);
		echo json_encode(array('status'=> true, 'message'=> 'Changes Saved!'));
	}else{
		echo json_encode(array('status'=> false, 'message'=> 'Something missing!'));
	}

	exit;
}
add_action('wp_ajax_single_retailer_discount', 'single_retailer_discount');
add_action('wp_ajax_nopriv_single_retailer_discount', 'single_retailer_discount');

/**
 * The default email message that will be sent to users as they are approved.
 *
 * @return string
 */
function new_user_approve_user_status() {

    $retailer_id = $_POST['retailer_id'];
    $mode = $_POST['mode'];

    $retailer_user_status = get_user_meta($retailer_id, 'retailer_user_status', true);

    if ($mode == 'true') {
		update_user_meta($retailer_id, 'retailer_user_status', 'approved');
		update_user_meta($retailer_id, 'new_registration', 'false');

       	$user = new WP_User( $retailer_id );
        // send email to user telling of approval
        $user_login = stripslashes( $user->data->user_login );
        $user_email = stripslashes( $user->data->user_email );
        // format the message
        $message = distributor_default_approve_user_message($user_login);
        $subject = sprintf( __( '[%s] Access Approved', 'distributor' ), get_option( 'blogname' ) );

        $headers = 'User Approved';

        send_email_woocommerce_style($user_email, $subject, $headers, $message);

		echo json_encode(array('status'=> true, 'message'=> 'User approved!'));
    }

    if($mode == 'false'){
		update_user_meta($retailer_id, 'retailer_user_status', 'unapproved');
		update_user_meta($retailer_id, 'new_registration', 'false');

       	$user = new WP_User( $retailer_id );
        // send email to user telling of approval
        $user_login = stripslashes( $user->data->user_login );
        $user_email = stripslashes( $user->data->user_email );
        // format the message
        $message = distributor_default_deny_user_message($user_login);
        $subject = sprintf( __( '[%s] Access Denied', 'distributor' ), get_option( 'blogname' ) );

        $headers = 'User Denied';

        send_email_woocommerce_style($user_email, $subject, $headers, $message);

		echo json_encode(array('status'=> true, 'message'=> 'User unapproved!'));
    }
    
    exit;

}
add_action( 'wp_ajax_new_user_approve_user_status', 'new_user_approve_user_status' );    // If called from admin panel
add_action( 'wp_ajax_nopriv_new_user_approve_user_status', 'new_user_approve_user_status' );    // If called from front end

add_action('woocommerce_order_status_changed', 'woo_order_status_change_custom', 10, 3);
function woo_order_status_change_custom($order_id,$old_status,$new_status) {
    
    $retailer_id = get_post_meta($order_id, '_customer_user', true);
    $retailer_meta = get_user_meta($retailer_id);
    

    $retailer_site_url      = $retailer_meta['retailer_site_url'][0];
    $retailer_key_id        = $retailer_meta['retailer_key'][0];
    $retailer_site_url      = $retailer_meta['retailer_site_url'][0];
    $order_meta             = get_post_meta($order_id);
    $_retailer_order_info   = $order_meta['_retailer_order_info'][0];
    $_retailer_product_info = $order_meta['_retailer_product_info'][0];
    $_created_via           = $order_meta['_created_via'][0];

    if ($_created_via == 'retailer_site') {
        $_retailer_order_info = unserialize(unserialize($_retailer_order_info));
        $retailer_products = unserialize(unserialize($_retailer_product_info));

        $retailer_order_id = $_retailer_order_info['order_id'];

        $products = [];
        foreach ($retailer_products as $key => $retailer_product) {
            $products[] = array('product_id' => $retailer_product['product_id']);
        }

        $verify_distributors       = verify_distributors_sitekey($retailer_key_id, $retailer_id, $retailer_site_url);
        $verify_retailer_response  = json_decode($verify_distributors, true);

        if ($verify_retailer_response['insert_in'] == true) {
            $retailer_order_update = retailer_order_update($retailer_id, $retailer_key_id, $retailer_site_url, $retailer_order_id, $products, $new_status);
            $order_update_response  = json_decode($retailer_order_update, true);
        }
    }
}

function get_users_by_role($role, $orderby, $order) {
    $args = array(
        'role'    => $role,
        'orderby' => $orderby,
        'order'   => $order
    );

    $users = get_users( $args );

    return $users;
}

// add_action( 'woocommerce_new_product', 'on_product_save', 10, 1 );
add_action( 'save_post', 'on_product_save');
function on_product_save( $post_id) {
    $product_id = $post_id;
    $post = get_post($product_id);
    global $woocommerce;
    if ( 'product' != $post->post_type ) {
        return;
    }

    $product = wc_get_product( $product_id );

    if (!$product ) {
        return;
    }

    $retailers = get_users_by_role('retailer', 'ID', 'ASC');

    foreach ($retailers as $key => $retailer) {

        $retailer_id = $retailer->ID;
        $retailer_meta = get_user_meta($retailer_id);

        $retailer_key_id        = $retailer_meta['retailer_key'][0];
        $retailer_site_url      = $retailer_meta['retailer_site_url'][0];

        $categories = array();
        $product_cats = get_the_terms(  $product->get_id(), 'product_cat' );
        if ($product_cats) {
            foreach($product_cats as $key => $cat) {
                $cat_data = array();
                $cat_data['term_id'] = $cat->term_id;
                $cat_data['name'] = $cat->name;
                $cat_data['slug'] = $cat->slug;
                $cat_data['image_url'] = '';
                $categories[] = $cat_data;
            }
        }

        $tags = array();
        $product_tag = get_the_terms(  $product->get_id(), 'product_tag' );
        if ($product_tag) {
            foreach($product_tag as $key => $tag) {
                $tag_data = array();
                $tag_data['term_id'] = $tag->term_id;
                $tag_data['name'] = $tag->name;
                $tag_data['slug'] = $tag->slug;
                $tag_data['image_url'] = '';
                $tags[] = $tag_data;
            }
        }
        
        $cat_name = array_column($categories, 'name');
        $tag_name = array_column($tags, 'name');
        $product_data['product_name']           = $product->get_name();
        $product_data['product_description']    = $product->get_description();
        $product_data['product_type']           = $product->get_type();
        $product_data['product_price']          = $product->get_price();
        $product_data['product_regular_price']  = $product->get_regular_price();
        $product_data['product_sale_price']     = $product->get_sale_price();

        $product_data['manage_stock']           = $product->get_manage_stock();
        $product_data['stock_status']           = $product->get_stock_status();

        $product_data['backorders']             = $product->get_backorders();
        $product_data['sold_individually']      = $product->get_sold_individually();

        $product_data['product_instock']        = $product->get_stock_status();
        $product_data['product_qty']            = $product->get_stock_quantity();
        $product_data['product_status']         = $product->get_status();
        $product_data['product_image']          = wp_get_attachment_url( $product->get_image_id() );
        $product_data['categories']             = $cat_name;
        $product_data['tags']                   = $tag_name;

        $verify_distributors       = verify_distributors_sitekey($retailer_key_id, $retailer_id, $retailer_site_url);
        $verify_retailer_response  = json_decode($verify_distributors, true);

        if ($verify_retailer_response['insert_in'] == true && $retailer_site_url) {
            $product_update_response = retailer_update_product($retailer_id, $retailer_key_id, $retailer_site_url, $product_id, $product_data);
            $product_update_response  = json_decode($product_update_response, true);
        }
    }
}