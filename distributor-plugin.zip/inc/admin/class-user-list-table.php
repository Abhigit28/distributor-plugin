<?php 

// WP_List_Table is not loaded automatically so we need to load it in our application
if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Retailers_List extends WP_List_Table {

    public function __construct() {
        parent::__construct( array(
        'singular' => 'retailer',
        'plural' => 'retailers',
        'ajax' => false
        ));
        $this->prepare_items();
        $this->display();
    }

    function get_columns() {
        $columns = array(
            'user_id' => __( 'Retailer Id', 'distributor' ),
            'username' => __( 'Username', 'distributor' ),
            // 'last_name' => __( 'Last Name', 'distributor' ),
            'user_email' => __( 'Email', 'distributor' ),
            'retailer_key' => __( 'Retailer Key', 'distributor' ),
            'user_registered' => __( 'Date / Time', 'distributor' ),
            'actions' => __( 'Actions', 'distributor' ),
        );
        return $columns;
    }

    function prepare_items() {

        global $wpdb, $_wp_column_headers;

        $siteid = get_current_blog_id();
        $screen = get_current_screen();
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable );
        $table_users = $wpdb->prefix ."users";
        $table_usermeta = $wpdb->prefix ."usermeta";
        $retailer_query = $wpdb->prepare("SELECT * FROM $table_users INNER JOIN $table_usermeta ON wp_users.ID = wp_usermeta.user_id WHERE wp_usermeta.meta_key = 'wp_capabilities' AND wp_usermeta.meta_value LIKE '%retailer%' ORDER BY wp_users.user_nicename");

        $total_retailers = $wpdb->get_results($retailer_query);
        $total_retailers = $wpdb->query( $retailer_query );
        $perpage = 15;
        // Which page is this?
        $paged = ! empty( $_GET['paged'] ) ? $_GET['paged'] : '';
        // Page Number
        if ( empty( $paged ) || ! is_numeric( $paged ) || $paged <= 0 ) {
            $paged = 1;
        }
        // How many pages do we have in total?
        $totalpages = ceil( $total_retailers / $perpage );
        // adjust the query to take pagination into account
        if ( ! empty( $paged ) && ! empty( $perpage ) ) {
            $offset = ( $paged - 1 ) * $perpage;
            $retailer_query .= ' LIMIT ' . (int) $offset . ',' . (int) $perpage;
        }

        $this->set_pagination_args(
            array(
                'total_items' => $total_retailers,
                'total_pages' => $totalpages,
                'per_page' => $perpage,
            )
        );
        // The pagination links are automatically built according to those parameters

        $_wp_column_headers[ $screen->id ] = $columns;
        $this->items = $wpdb->get_results( $retailer_query );

    }

    function column_default( $item, $column_name) {
        global $post, $wp_list_table, $wpdb;

        $user_meta = get_user_meta($item->ID);
        $retailer_key = $user_meta['retailer_key'][0];

        switch($column_name) {
            case 'user_id':
            return '<a href="/wp-admin/admin.php?page=distributor-page&tab=retailer-list&action=view&retailer_id='.$item->ID.'"><strong>#'.$item->ID.'</strong></a>';
            break;
            case 'username':
            return $item->display_name;
            break;
            // case 'last_name':
            // return $item->last_name;
            // break;
            case 'user_email':
            return $item->user_email;
            break;
            case 'retailer_key':
            return $retailer_key;
            break;
            case 'user_registered':
            return $item->user_registered;
            break;
            case 'actions':
            return '<a href="/wp-admin/admin.php?page=distributor-page&tab=retailer-list&action=view&retailer_id='.$item->ID.'"><strong>View</strong></a>';
            break;
        }
    }
}