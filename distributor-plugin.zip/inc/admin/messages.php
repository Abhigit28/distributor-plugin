<?php 

/**
 * The default email message that will be sent to users as they are approved.
 *
 * @return string
 */
function distributor_default_approve_user_message($user_login) {
	$message = sprintf( __( 'Hello %s,', 'distributor' ), $user_login ) . "\r\n\r\n";
	$message .= sprintf( __( 'You have been approved to access %s.', 'distributor' ), get_option( 'blogname' ) ) . "\r\n\r\n";
	$message .= sprintf( __( 'You can access your account area at: %s.', 'distributor' ), esc_url( wc_get_page_permalink( 'myaccount' ) ) ) . "\r\n\r\n";

	$message .= __("Thank You", "distributor");

	return $message;
}

/**
 * The default email message that will be sent to users as they are denied.
 *
 * @return string
 */
function distributor_default_deny_user_message($user_login) {
	$message = sprintf( __( 'Hello %s,', 'distributor' ), $user_login ) . "\r\n\r\n";
	$message .= sprintf( __( 'You have been denied access to %s.', 'distributor' ), get_option( 'blogname' ) ) . "\r\n\r\n";
	$message .= __("Thank You", "distributor");

	return $message;
}