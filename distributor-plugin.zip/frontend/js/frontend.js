function copyretailerkey() {
    var copyText = document.getElementById("retailer_key");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);

    var tooltip = document.getElementById("retailerkeyTooltip");
    tooltip.innerHTML = "Copied: " + copyText.value;
}

function outFunc() {
    var tooltip = document.getElementById("retailerkeyTooltip");
    tooltip.innerHTML = "Copy to clipboard";
}