<?php

/**
* Plugin Name: Distributor Plugin
* Plugin URI: https://eoxysit.com/
* Description: Distributor Plugin for WooCommerce.
* Version: 1.0.0
* Author: Eoxys IT Dev
* Author URI: https://eoxysit.com/
* Text Domain: distributor
**/

if ( ! defined( 'ABSPATH' ) ) {
    die('security by preventing any direct access to your plugin file');
}

require_once ABSPATH . 'wp-admin/includes/plugin.php';
@include_once "inc/admin/messages.php";
@include_once "includes/api/distributor-api.php";
@include_once "inc/admin/admin-ajax-function.php";
@include_once "includes/class-retailers.php";
@include_once "includes/class-products.php";
@include_once "includes/class-create-order.php";
@include_once "includes/stripe/config.php";
@include_once "includes/stripe/stripe-php/init.php";

// @include_once "includes/stripe/WooPaymentstripe.php";

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) or is_plugin_active_for_network( 'woocommerce/woocommerce.php' ) ) {

        @include_once "distributor-myaccount/distributor-account.php";

        global $woocommerce;

        add_action( 'wp_enqueue_scripts', 'distributor_my_enqueue', 99);
        add_action( 'admin_enqueue_scripts', 'distributor_my_enqueue', 99);
        function distributor_my_enqueue($hook) {
            wp_enqueue_style( 'distributor-style', plugins_url( '/assets/css/distributor.css', __FILE__ ) );
            wp_enqueue_style( 'distributor-frontend-style', plugins_url( '/frontend/css/frontend.css', __FILE__ ) );
            wp_enqueue_script( 'distributor-script', plugins_url( '/assets/js/distributor.js', __FILE__ ), array('jquery') );
            wp_enqueue_script( 'distributor-frontend-script', plugins_url( '/frontend/js/frontend.js', __FILE__ ), array('jquery') );
            wp_localize_script( 'ajax-script', 'my_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
            
            wp_enqueue_style( 'distributor-dataTables-style', plugins_url( '/assets/lib/dataTables/jquery.dataTables.min.css', __FILE__ ) );
            wp_enqueue_script( 'distributor-dataTables-script', plugins_url( '/assets/lib/dataTables/jquery.dataTables.min.js', __FILE__ ), array('jquery') );
        }

        // add parent category to site menu
        function distributor_add_settings_page() {
            if ( !empty ( $GLOBALS['admin_page_hooks']['distributor_plugins'] ) ) {
                return;
            }

            add_menu_page(
                esc_html__("Distributor", "distributor"), 
                esc_html__("Distributor", "distributor"), 
                "NULL", 
                "distributor_plugins", 
                "sc_menu_page", 
                "dashicons-store", 
                50,
            );
            //call register settings function
            add_action( 'admin_init', 'register_distributor_plugins_settings' );
        }
        add_action( 'admin_menu', 'distributor_add_settings_page' );

        // add child category to parent to site menu
        function distributor_add_submenu_pages() {
            add_submenu_page(
                "distributor_plugins",
                esc_html__("Distributor Plugin", "distributor"),
                esc_html__("Distributor Plugin", "distributor"), 
                "manage_options",
                "distributor-page",
                "distributor_render_plugin_settings_page"
            );
        }
        add_action( 'admin_menu', 'distributor_add_submenu_pages' );

        function register_distributor_plugins_settings() {
            //register our settings
            register_setting( 'distributor-plugin-genral-tab', 'distributor_key_id' );
            register_setting( 'distributor-plugin-setting-tab', 'enable_register_form' );
            register_setting( 'distributor-plugin-setting-tab', 'global_discount_title' );
            register_setting( 'distributor-plugin-setting-tab', 'global_discount_enable' );
            register_setting( 'distributor-plugin-setting-tab', 'global_discount' );
        }

        // render form
        function distributor_render_plugin_settings_page() {
            // check user capabilities
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            //Get the active tab from the $_GET param
            $general_tab = null;
            $tab = isset($_GET['tab']) ? $_GET['tab'] : $general_tab;
            ?>          

            <!-- Our admin page content should all be inside .wrap -->
                <div class="distributor-page-layout__header">
                    <h1 class="distributor-layout__header-heading"><?php echo esc_html( get_admin_page_title() ); ?></h1>
                </div>
                <div class="wrap" style="margin-top: 80px;">
                    <!-- Print the page title -->
                    <!-- Here are our tabs -->
                    <?php settings_errors(); ?> 
                    <nav class="nav-tab-wrapper">
                        <a href="?page=distributor-page" class="nav-tab <?php if($tab===null):?>nav-tab-active<?php endif; ?>">Settings</a>
                        <!-- <a href="?page=distributor-page&tab=settings" class="nav-tab <?php //if($tab==='settings'):?>nav-tab-active<?php //endif; ?>">Settings</a> -->
                        <a href="?page=distributor-page&tab=retailer-list" class="nav-tab <?php if($tab==='retailer-list'):?>nav-tab-active<?php endif; ?>">Retailer List</a>
                    </nav>
                    <div class="tab-content">
                    <?php switch($tab) :
                        case 'settings': ?>
                            <?php @include_once 'distributor-tab/general-tab.php';
                            break;
                        case 'retailer-list': ?>
                            <?php @include_once 'distributor-tab/retailer-list-tab.php';
                            break;
                        default:?>
                            <?php @include_once 'distributor-tab/settings-tab.php';
                            break;
                        endswitch; ?>
                    </div>
              </div>
            <?php
        }

}else{

    add_action( 'admin_notices', 'distributor_auction_error_notice' );
    function distributor_auction_error_notice() {
        global $current_screen;

        if ( $current_screen->parent_base == 'plugins' ) {
            echo '<div class="error"><p>'.esc_html__('distributor plugin requires WooCommerce to be activated in order to work. Please install and activate', 'distributor').' <a href="' . admin_url( 'plugin-install.php?tab=search&type=term&s=WooCommerce' ) . '" target="_blank">'.esc_html__('WooCommerce', 'distributor').'</a> '.esc_html__('first', 'distributor').'</p></div>';
        }
    }
}

function distributor_is_dokan_activate(){
    if (in_array( 'dokan-lite/dokan.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) )) {
        return true;
    }else{
        return false;
    }
}

function distributor_is_wcfm_activate(){
    if(in_array( 'wc-multivendor-marketplace/wc-multivendor-marketplace.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) )) {
        return true;
    }else{
        return false;
    }
}

function distributor_default_registeration_welcome_email($user_login, $user_email) {
    $message = sprintf( __( 'Hello %s,', 'distributor' ), $user_login ) . "\r\n\r\n";
    
    $message .= __("Thank you for registering on our site. We have successfully received your request and is currently pending for approval.", "distributor") . "\r\n";
    
    $message .= __("The administrator will review the information that has been submitted after which they will either approve or deny your request. You will receive an email with the instructions on what you will need to do next.", "distributor") . "\r\n\r\n";
    
    $message .= __("Thank You", "distributor");

    $subject = sprintf( __( 'Your registration is pending for approval - [%s]', 'distributor' ), get_option( 'blogname' ) );
    
    $admin_email = get_option( 'admin_email' );
    if ( isset($_SERVER['SERVER_NAME']) && empty($admin_email) ) {
        $admin_email = 'support@' . sanitize_text_field(wp_unslash($_SERVER['SERVER_NAME']));
    }
    $from_name = get_option( 'blogname' );
    $headers = array( "From: \"{$from_name}\" <{$admin_email}>\n" );

    // send the mail
    wp_mail(
        $user_email,
        $subject,
        $message,
        $headers
    );
}

function user_has_role($user_id, $role_name){
    $user_meta = get_userdata($user_id);
    $user_roles = $user_meta->roles;
    return in_array($role_name, $user_roles);
}

// Applying conditionally a discount for a specific user role
add_action( 'woocommerce_cart_calculate_fees', 'discount_based_on_user_role', 20, 1 );
function discount_based_on_user_role( $cart ) {
    global $wpdb, $woocommerce;

    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return; // Exit

    // Only for 'company' user role
    if ( ! current_user_can('retailer') )
        return; // Exit

    // HERE define the retailer_discount discount

    $user_is_retailer = user_has_role(get_current_user_id(), 'retailer');

    $retailer_id = get_current_user_id();

    $retailer_meta = get_user_meta($retailer_id);
    
    $retailer_site_url          = $retailer_meta['retailer_site_url'][0];
    $retailer_discount_title    = $retailer_meta['discount_title'][0];
    $_retailer_discount         = $retailer_meta['retailer_discount'][0];

    $global_discount            = get_option('global_discount');
    $global_discount_title      = get_option('global_discount_title');
    $global_discount_enable     = get_option('global_discount_enable');

    if ($global_discount_enable == 'yes') {
        if (!empty($retailer_discount_title)) {
            $discount_title = $retailer_discount_title;
        }elseif (empty($retailer_discount_title) && !empty($global_discount_title)) {
            $discount_title = $global_discount_title;
        }else{
            $discount_title = 'Discount';
        }

        if (!empty($_retailer_discount)) {
            $retailer_discount = $_retailer_discount;
        }elseif (empty($_retailer_discount) && !empty($global_discount)) {
            $retailer_discount = $global_discount;
        }else{
            $retailer_discount = '0';
        }

        $discount = $cart->get_subtotal() * $retailer_discount / 100; // Calculation

        // Applying discount
        $cart->add_fee( sprintf( __("".$discount_title." (%s)", "woocommerce"), $retailer_discount . '%'), -$discount, true );
    }
}

// echo "<pre>";
// print_r(get_user_meta(2));
// echo "</pre>";