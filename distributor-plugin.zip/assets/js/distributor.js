jQuery(document).ready(function(){
	var ajaxurl = "/wp-admin/admin-ajax.php";

    jQuery(document).on('click', '#single_retailer_discount', function(){
        var retailer_id = jQuery('#retailer_id').val();
        var discount_title = jQuery('#_retailer_discount_title').val();
        var retailer_discount = jQuery('#_retailer_discount').val();

        if (!retailer_id && !retailer_discount) {
            jQuery('.distributor-notice').html('<p>Please insert discount rate.</p>');
        }else{
            jQuery.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: "single_retailer_discount",
                    retailer_id: retailer_id,
                    discount_title: discount_title,
                    retailer_discount: retailer_discount,
                },
                success: function (response) {
                    var responseData = jQuery.parseJSON(response);
                    if (responseData.status == true) {
                        jQuery('.distributor-notice').html('<h3 style="color: green;text-align: center;">'+responseData.message+'</h3>');
                    }else{
                        jQuery('.distributor-notice').html('<h3 style="color: red;text-align: center;">'+responseData.message+'</h3>');
                    }
                }
            });
        }
    });

    jQuery('.user_status_toggle').change(function(){
        var mode = jQuery(this).prop('checked');
        var retailer_id= jQuery(this).attr('retailer_id');

        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: "new_user_approve_user_status",
                retailer_id: retailer_id,
                mode: mode,
            },
            success: function (response) {
                var responseData = jQuery.parseJSON(response);
                console.log(responseData);
            }
        });
      });
});

jQuery(document).ready(function () {
    // Setup - add a text input to each footer cell
    // jQuery('.table-view-list.retailers thead tr').clone(true).addClass('filters').appendTo('.table-view-list.retailers thead');
 
    var table = jQuery('.table-view-list.retailers').DataTable({
        orderCellsTop: true,
        fixedHeader: true,
        initComplete: function () {
            var api = this.api();
 
            // For each column
            api
                .columns()
                .eq(0)
                .each(function (colIdx) {
                    // Set the header cell to contain the input element
                    var cell = jQuery('.filters th').eq(
                        jQuery(api.column(colIdx).header()).index()
                    );
                    var title = jQuery(cell).text();
                    jQuery(cell).html('<input type="text" placeholder="' + title + '" />');
 
                    // On every keypress in this input
                    jQuery(
                        'input',
                        jQuery('.filters th').eq(jQuery(api.column(colIdx).header()).index())
                    )
                        .off('keyup change')
                        .on('change', function (e) {
                            // Get the search value
                            jQuery(this).attr('title', jQuery(this).val());
                            var regexr = '({search})'; //jQuery(this).parents('th').find('select').val();
 
                            var cursorPosition = this.selectionStart;
                            // Search the column for that value
                            api
                                .column(colIdx)
                                .search(
                                    this.value != ''
                                        ? regexr.replace('{search}', '(((' + this.value + ')))')
                                        : '',
                                    this.value != '',
                                    this.value == ''
                                )
                                .draw();
                        })
                        .on('keyup', function (e) {
                            e.stopPropagation();
 
                            jQuery(this).trigger('change');
                            jQuery(this)
                                .focus()[0]
                                .setSelectionRange(cursorPosition, cursorPosition);
                        });
                });
        },
    });
});