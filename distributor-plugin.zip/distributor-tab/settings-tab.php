<h3 class="title">Distributor Settings</h3>

<section id="distributor_settings_section">

    <form method="post" action="options.php">

        <?php settings_fields('distributor-plugin-setting-tab'); ?>

        <div id="distributor_retailer">

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Register as a Retailer</th>
                    <td>
                        <input type="checkbox" id="enable_register_form" name="enable_register_form" value="yes" <?php checked( 'yes' == get_option( 'enable_register_form' ) ); ?><?php checked( 'enable_register_form', get_option( 'enable_register_form' ) ); ?>>
                        <p class="description">Please check the checkbox to enable the Retailer user role and enable it in the registration form</p>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Global Retailer Discount</th>
                    <td>
                        <input type="checkbox" id="global_discount_enable" name="global_discount_enable" value="yes" <?php checked( 'yes' == get_option( 'global_discount_enable' ) ); ?><?php checked( 'global_discount_enable', get_option( 'global_discount_enable' ) ); ?>>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Discount Title</th>
                    <td>
                        <input type="text" id="global_discount_title" name="global_discount_title" style="width: 400px;" value="<?php echo get_option( 'global_discount_title' ); ?>">
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row">Retailer Discount</th>
                    <td>
                        <input type="number" id="global_discount" name="global_discount" style="width: 400px;" value="<?php echo get_option( 'global_discount' ); ?>" step="1" oninput="global_discount(this)">
                        <p class="description">This discount amount is in %.</p>
                    </td>
                </tr>
            </table>

        </div>      

        <?php submit_button(); ?>

    </form>

</section>

