<?php 

if ($_GET['action'] == 'retailer_data' && $_GET['retailer_id']) { 

    global $wpdb;

    $retailer_id = $_GET['retailer_id'];
    $user_meta = get_user_meta($retailer_id);

?>
    
    <h3 class="title">Retailer</h3>
    <section id="retailer_info">
        <p>Retailer Id : <?php echo $retailer_id; ?></p>
        <p>Retailer Key : <?php echo $user_meta['retailer_key'][0]; ?></p>

        <form method="post" action="options.php">
            <div id="distributor_retailer">
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Discount Title</th>
                        <td>
                            <input type="text" id="_retailer_discount_title" name="_retailer_discount_title" style="width: 400px;" value="<?php echo $user_meta['discount_title'][0]; ?>">
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Discount</th>
                        <td>
                            <input type="text" id="_retailer_discount" name="_retailer_discount" style="width: 400px;" value="<?php echo $user_meta['retailer_discount'][0]; ?>">
                            <p class="description">This discount amount is in %.</p>
                        </td>
                    </tr>
                </table>
            </div>      
            <p class="submit">
                <input type="hidden" name="retailer_id" id="retailer_id" value="<?php echo $retailer_id; ?>">
                <input type="button" name="single_retailer_discount" id="single_retailer_discount" class="button button-primary" value="Save Changes">
            </p>
            <div class="distributor-notice"></div>
        </form>
    </section>
    <button class="button" id="back_btn" onclick="history.back()">Go Back</button>
<?php }else{ ?>
    <h3 class="title">Retailers List</h3>
    <section id="retailers_list">
        <?php 

            // WP_List_Table is not loaded automatically so we need to load it in our application
            if( ! class_exists( 'WP_List_Table' ) ) {
                require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
            }

            class Retailers_List extends WP_List_Table {

                public function __construct() {
                    parent::__construct( array(
                    'singular' => 'retailer',
                    'plural' => 'retailers',
                    'ajax' => false
                    ));
                    $this->prepare_items();
                    $this->display();
                }

                function get_columns() {
                    $columns = array(
                        'user_id'           => __( 'Retailer Id', 'distributor' ),
                        'username'          => __( 'Username', 'distributor' ),
                        'user_email'        => __( 'Email', 'distributor' ),
                        'retailer_key'      => __( 'Retailer Key', 'distributor' ),
                        'site_url'          => __( 'Site Url', 'distributor' ),
                        // 'user_registered'   => __( 'Date / Time', 'distributor' ),
                        'retailer_discount' => __( 'Dicount(in %)', 'distributor' ),
                        // 'actions'           => __( 'Actions', 'distributor' ),
                        'user_status'            => __( 'User Status', 'distributor' ),
                    );
                    return $columns;
                }

                // function get_sortable_columns() {
                //     return $sortable = array(
                //         'user_id'       => array('user_id',false),
                //         'username'      => array('username',false),
                //         'user_email'    => array('user_email',false)
                //     );
                // }

                function no_items() {
                  _e('No retailers to display', 'distributor');
                }

                function prepare_items() {

                    global $wpdb, $_wp_column_headers;

                    $siteid = get_current_blog_id();
                    $screen = get_current_screen();
                    $columns = $this->get_columns();
                    $hidden = array();
                    $sortable = $this->get_sortable_columns();
                    $this->_column_headers = array( $columns, $hidden, $sortable );
                    $table_users = $wpdb->prefix ."users";
                    $table_usermeta = $wpdb->prefix ."usermeta";
                    $retailer_query = $wpdb->prepare("SELECT * FROM $table_users INNER JOIN $table_usermeta ON wp_users.ID = wp_usermeta.user_id WHERE wp_usermeta.meta_key = 'wp_capabilities' AND wp_usermeta.meta_value LIKE '%retailer%' ORDER BY wp_users.ID");

                    $total_retailers = $wpdb->get_results($retailer_query);
                    $total_retailers = $wpdb->query( $retailer_query );
                    $perpage = 15;
                    // Which page is this?
                    $paged = ! empty( $_GET['paged'] ) ? $_GET['paged'] : '';
                    // Page Number
                    if ( empty( $paged ) || ! is_numeric( $paged ) || $paged <= 0 ) {
                        $paged = 1;
                    }
                    // How many pages do we have in total?
                    $totalpages = ceil( $total_retailers / $perpage );
                    // adjust the query to take pagination into account
                    if ( ! empty( $paged ) && ! empty( $perpage ) ) {
                        $offset = ( $paged - 1 ) * $perpage;
                        $retailer_query .= ' LIMIT ' . (int) $offset . ',' . (int) $perpage;
                    }

                    // $this->set_pagination_args(
                    //     array(
                    //         'total_items' => $total_retailers,
                    //         'total_pages' => $totalpages,
                    //         'per_page' => $perpage,
                    //     )
                    // );
                    // The pagination links are automatically built according to those parameters

                    $_wp_column_headers[ $screen->id ] = $columns;
                    $this->items = $wpdb->get_results( $retailer_query );

                }

                function column_default( $item, $column_name) {
                    global $post, $wp_list_table, $wpdb;

                    $user_meta = get_user_meta($item->ID);
                    $retailer_key = $user_meta['retailer_key'][0];
                    $retailer_site_url = $user_meta['retailer_site_url'][0];
                    $retailer_discount = $user_meta['retailer_discount'][0];
                    $retailer_user_status = $user_meta['retailer_user_status'][0];

                    if ($retailer_user_status == 'approved') {
                        $checked = 'checked';
                        $disabled = 'disabled';
                    }else{
                        $checked = '';
                        $disabled = '';
                    }

                    $output    = '';
             
                    // Title.
                    $output .= '<strong><a href="/wp-admin/admin.php?page=distributor-page&tab=retailer-list&action=retailer_data&retailer_id='.$item->ID.'" class="row-title">#'.$item->ID.'</a></strong>';
                    
                    // Get actions.
                    $actions = array(
                        'edit'   => '<a href="'. get_edit_user_link( $item->ID ) .'">' . esc_html__( 'Edit', 'distributor' ) . '</a>',
                        'view'   => '<a href="/wp-admin/admin.php?page=distributor-page&tab=retailer-list&action=retailer_data&retailer_id='.$item->ID.'">' . esc_html__( 'View', 'distributor' ) . '</a>',
                    );
             
                    $row_actions = array();
             
                    foreach ( $actions as $action => $link ) {
                        $row_actions[] = '<span class="' . esc_attr( $action ) . '">' . $link . '</span>';
                    }
             
                    $output .= '<div class="row-actions">' . implode( ' | ', $row_actions ) . '</div>';

                    switch($column_name) {
                        case 'user_id':
                        return $output;
                        break;
                        case 'username':
                        return $item->display_name;
                        break;
                        case 'user_email':
                        return $item->user_email;
                        break;
                        case 'retailer_key':
                        return $retailer_key;
                        break;
                        case 'site_url':
                        return $retailer_site_url;
                        break;
                        // case 'user_registered':
                        // return $item->user_registered;
                        // break;
                        case 'retailer_discount':
                        return $retailer_discount;
                        break;
                        // case 'actions':
                        // return '<a href="/wp-admin/admin.php?page=distributor-page&tab=retailer-list&action=retailer_data&retailer_id='.$item->ID.'"><strong>View</strong></a>';
                        // break;
                        case 'user_status':
                        return '<label class="switch"><input type="checkbox" name="toggle" class="user_status_toggle" data-toggle="toggle" data-off="Unapproved" data-on="Approved" retailer_id="'.$item->ID.'" '.$checked.' '.$disabled.'><span class="slider round"></span></label>';
                        break;
                    }
                }
            }

            $retailers = new Retailers_List(); 

        ?>
    </section>
<?php } ?>

