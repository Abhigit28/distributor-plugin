<h3 class="title">Distributor Details</h3>
<form method="post" action="options.php">
    <?php settings_fields('distributor-plugin-genral-tab'); ?>
    <div id="distributor_flat_type">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Distributor Key Id</th>
                <td>
                    <input type="text" id="distributor_key_id" name="distributor_key_id" value="<?php echo get_option( 'distributor_key_id' ); ?>">
                    <p class="description">This is Key id.</p>
                </td>
            </tr>
        </table>
    </div>      
    <?php submit_button(); ?>
</form>
  